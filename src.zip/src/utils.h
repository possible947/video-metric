#ifndef UTILS_H
#define UTILS_H

#include "metrics.h"

int file_exists(const char *path);
int create_temp_dir(char *buf, size_t buflen);
int parse_ssim_log(const char *log_path, stats_t *out);
int parse_vmaf_json(const char *json_path, stats_t *out);
void print_stats(const char *metric, const stats_t *s);
int remove_temp_dir(const char *path);

#endif /* UTILS_H */

