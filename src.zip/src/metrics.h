#ifndef METRICS_H
#define METRICS_H

#include "args.h"

typedef struct {
    double min;
    double max;
    double avg;
} stats_t;

int calculate_ssim(const cli_options *opts, stats_t *out);
int calculate_vmaf(const cli_options *opts, stats_t *out);

#endif /* METRICS_H */

