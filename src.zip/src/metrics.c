#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#define _POSIX_C_SOURCE 200809L
#include <limits.h>          /* ← добавлено для PATH_MAX */
#include <float.h>           /* ← добавлено для DBL_MAX */
#include "metrics.h"
#include "utils.h"

static const char *HD_MODEL = "/usr/share/model/vmaf_v0.6.1.json";
static const char *K4_MODEL = "/usr/share/model/vmaf_4k_v0.6.1.json";

int calculate_ssim(const cli_options *opts, stats_t *out) {
    char tmpdir[PATH_MAX];
    if (create_temp_dir(tmpdir, sizeof(tmpdir)) != 0) {
        fprintf(stderr, "Error: could not create temporary directory\n");
        return 1;
    }

    char log_path[PATH_MAX];
    snprintf(log_path, sizeof(log_path), "%s/ssim.log", tmpdir);

    char cmd[2048];
    snprintf(cmd, sizeof(cmd),
        "ffmpeg -y -i \"%s\" -i \"%s\" -threads %d -vf \"ssim=stats_file=%s\" -f null -",
        opts->original, opts->test, opts->num_threads, log_path);

    if (system(cmd) != 0) {
        fprintf(stderr, "Error: ffmpeg command failed\n");
        remove_temp_dir(tmpdir);
        return 1;
    }

    if (parse_ssim_log(log_path, out) != 0) {
        fprintf(stderr, "Error: could not parse SSIM log\n");
        remove_temp_dir(tmpdir);
        return 1;
    }

    remove_temp_dir(tmpdir);
    return 0;
}

int calculate_vmaf(const cli_options *opts, stats_t *out) {
    char tmpdir[PATH_MAX];
    if (create_temp_dir(tmpdir, sizeof(tmpdir)) != 0) {
        fprintf(stderr, "Error: could not create temporary directory\n");
        return 1;
    }

    char json_path[PATH_MAX];
    snprintf(json_path, sizeof(json_path), "%s/vmaf.json", tmpdir);

    const char *model_path = (strcmp(opts->resolution, "hd") == 0) ? HD_MODEL : K4_MODEL;

    char cmd[2048];
    snprintf(cmd, sizeof(cmd),
        "ffmpeg -y -i \"%s\" -i \"%s\" -threads %d -vf \"libvmaf=model=path=%s:log_path=%s\" -f null -",
        opts->original, opts->test, opts->num_threads, model_path, json_path);

    if (system(cmd) != 0) {
        fprintf(stderr, "Error: ffmpeg command failed\n");
        remove_temp_dir(tmpdir);
        return 1;
    }

    if (parse_vmaf_json(json_path, out) != 0) {
        fprintf(stderr, "Error: could not parse VMAF JSON\n");
        remove_temp_dir(tmpdir);
        return 1;
    }

    remove_temp_dir(tmpdir);
    return 0;
}

