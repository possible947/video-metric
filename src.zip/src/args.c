#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include "args.h"

static void print_usage(const char *prog) {
    fprintf(stderr,
        "Usage: %s -o <original> -t <test> (-s | -v -r <hd|4k>) [-n <threads>] [-h]\n"
        "Options:\n"
        "  -o, --output        Original video file (required)\n"
        "  -t, --test          Test video file (required)\n"
        "  -s, --ssim          Compute SSIM (mutually exclusive with -v)\n"
        "  -v, --vmaf          Compute VMAF (mutually exclusive with -s)\n"
        "  -r, --resolution    VMAF resolution: hd or 4k (required if -v)\n"
        "  -n, --num_threads   Number of ffmpeg threads (default 1)\n"
        "  -h, --help          Show this help message\n",
        prog);
}

int parse_args(int argc, char **argv, cli_options *opts) {
    memset(opts, 0, sizeof(*opts));
    opts->num_threads = 1;   /* default */

    static struct option longopts[] = {
        {"output",      required_argument, 0, 'o'},
        {"test",        required_argument, 0, 't'},
        {"ssim",        no_argument,       0, 's'},
        {"vmaf",        no_argument,       0, 'v'},
        {"resolution",  required_argument, 0, 'r'},
        {"num_threads", required_argument, 0, 'n'},
        {"help",        no_argument,       0, 'h'},
        {0,0,0,0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "o:t:svr:n:h", longopts, NULL)) != -1) {
        switch (opt) {
        case 'o': opts->original = optarg; break;
        case 't': opts->test = optarg; break;
        case 's': opts->ssim_flag = true; break;
        case 'v': opts->vmaf_flag = true; break;
        case 'r':
            if (strcmp(optarg, "hd") == 0 || strcmp(optarg, "4k") == 0)
                strcpy(opts->resolution, optarg);
            else {
                fprintf(stderr, "Error: invalid resolution '%s'\n", optarg);
                return 1;
            }
            break;
        case 'n':
            opts->num_threads = atoi(optarg);
            if (opts->num_threads <= 0) {
                fprintf(stderr, "Error: number of threads must be positive\n");
                return 1;
            }
            break;
        case 'h':
            opts->help_flag = true;
            break;
        default:
            print_usage(argv[0]);
            return 1;
        }
    }

    if (opts->help_flag) {
        print_usage(argv[0]);
        return 0;
    }

    /* Validate required options */
    if (!opts->original || !opts->test) {
        fprintf(stderr, "Error: both -o/--output and -t/--test are required\n");
        return 1;
    }

    if (opts->ssim_flag && opts->vmaf_flag) {
        fprintf(stderr, "Error: cannot specify both -s/--ssim and -v/--vmaf\n");
        return 1;
    }
    if (!opts->ssim_flag && !opts->vmaf_flag) {
        fprintf(stderr, "Error: must specify either -s/--ssim or -v/--vmaf\n");
        return 1;
    }
    if (opts->vmaf_flag && opts->resolution[0] == '\0') {
        fprintf(stderr, "Error: -r/--resolution is required when using VMAF\n");
        return 1;
    }

    return 0;
}

