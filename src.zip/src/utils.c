#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <jansson.h>
#include <limits.h>
#include <float.h>
#include "utils.h"

int file_exists(const char *path) {
    struct stat st;
    return (stat(path, &st) == 0 && S_ISREG(st.st_mode));
}

int create_temp_dir(char *buf, size_t buflen) {
    const char *tmpl = "/tmp/video-metrics-XXXXXX";
    if (strlen(tmpl) + 1 > buflen) return -1;
    strncpy(buf, tmpl, buflen);
    char *tmp = mkdtemp(buf);
    return tmp ? 0 : -1;
}

int parse_ssim_log(const char *log_path, stats_t *out) {
    FILE *fp = fopen(log_path, "r");
    if (!fp) return -1;

    double val, sum = 0.0;
    int count = 0;
    out->min = DBL_MAX;
    out->max = -DBL_MAX;

    char line[256];
    while (fgets(line, sizeof(line), fp)) {
        if (sscanf(line, "ssim: %lf", &val) == 1) {
            if (val < out->min) out->min = val;
            if (val > out->max) out->max = val;
            sum += val;
            count++;
        }
    }
    fclose(fp);
    if (count == 0) return -1;
    out->avg = sum / count;
    return 0;
}

int parse_vmaf_json(const char *json_path, stats_t *out) {
    json_error_t error;
    json_t *root = json_load_file(json_path, 0, &error);
    if (!root) return -1;

    json_t *frames = json_object_get(root, "frames");
    if (!frames || !json_is_array(frames)) {
        json_decref(root);
        return -1;
    }

    size_t i;
    double sum = 0.0;
    int count = 0;
    out->min = DBL_MAX;
    out->max = -DBL_MAX;

    for (i = 0; i < json_array_size(frames); i++) {
        json_t *frame = json_array_get(frames, i);
        if (!frame) continue;

        json_t *metrics = json_object_get(frame, "metrics");
        if (!metrics) continue;

        json_t *vmaf = json_object_get(metrics, "vmaf");
        if (!vmaf || !json_is_number(vmaf)) continue;

        double val = json_number_value(vmaf);
        if (val < out->min) out->min = val;
        if (val > out->max) out->max = val;
        sum += val;
        count++;
    }

    json_decref(root);
    if (count == 0) return -1;
    out->avg = sum / count;
    return 0;
}

void print_stats(const char *metric, const stats_t *s) {
    /* Placeholder: not used in current code */
    printf("Metric: %s\n", metric);
    printf("Min: %.4f\n", s->min);
    printf("Max: %.4f\n", s->max);
    printf("Avg: %.4f\n", s->avg);
}

int remove_temp_dir(const char *path) {
    /* Simple recursive delete using system; safe for this small temp dir */
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "rm -rf %s", path);
    return system(cmd);
}

