#ifndef ARGS_H
#define ARGS_H

#include <stdbool.h>

typedef struct {
    const char *original;
    const char *test;
    bool ssim_flag;
    bool vmaf_flag;
    char resolution[4];      /* "hd" or "4k" */
    int num_threads;
    bool help_flag;
} cli_options;

int parse_args(int argc, char **argv, cli_options *opts);

#endif /* ARGS_H */

