#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "args.h"
#include "metrics.h"
#include "utils.h"

int main(int argc, char **argv) {
    cli_options opts;
    if (parse_args(argc, argv, &opts) != 0) return 1;
    if (opts.help_flag) return 0;

    if (!file_exists(opts.original)) {
        fprintf(stderr, "Error: original file '%s' does not exist\n", opts.original);
        return 1;
    }
    if (!file_exists(opts.test)) {
        fprintf(stderr, "Error: test file '%s' does not exist\n", opts.test);
        return 1;
    }

    stats_t stats;
    if (opts.ssim_flag) {
        if (calculate_ssim(&opts, &stats) != 0) return 1;
        printf("Original file: %s\n", opts.original);
        printf("Test file: %s\n\n", opts.test);
        printf("Metric: SSIM\n");
        printf("Min: %.4f\n", stats.min);
        printf("Max: %.4f\n", stats.max);
        printf("Avg: %.4f\n", stats.avg);
    } else if (opts.vmaf_flag) {
        if (calculate_vmaf(&opts, &stats) != 0) return 1;
        printf("Original file: %s\n", opts.original);
        printf("Test file: %s\n\n", opts.test);
        printf("Metric: VMAF\n");
        printf("Min: %.4f\n", stats.min);
        printf("Max: %.4f\n", stats.max);
        printf("Avg: %.4f\n", stats.avg);
    }

    return 0;
}

